#    The contents of this file are subject to the Mozilla Public License
#    Version  2.0  (the "License"); you may not use this file except in
#    compliance with the License. You may obtain a copy of the License at:
#
#    http://www.mozilla.org/MPL/
#
#    Software  distributed  under  the License is distributed on an "AS
#    IS"  basis,  WITHOUT  WARRANTY  OF  ANY  KIND,  either  express or
#    implied.
#
# Purpose: EXECUTE THE EVALUATION AND RECORD ITS RESULTS
# Author : Ramiz Gindullin, Uppsala University


import os.path
import subprocess
import time
import csv
import re
import numpy as np
from pathlib import Path
from collections import defaultdict, Counter
from io import StringIO

# functions:
def get_config_file(path, config):
    return path + config + '.mpc'

def run_cmd(minizinc_path, project_path,
            solver_config_name, model_files_list, data_directory, data_file):
    solver_config = get_config_file(project_path, solver_config_name)
    model_file = ''
    for model in model_files_list:
        model_file += project_path + model + '.mzn '
    data_file = data_directory + data_file
    cmd = minizinc_path + ' --param-file-no-push ' + solver_config + ' ' + model_file + data_file
    process = subprocess.Popen([cmd], shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    #retval = process.wait()
    output, _ = process.communicate()
    output = output.decode('utf-8').strip()
    process.kill()
    return output

# for COMPD layouts
def extract_info(data_text):
    rows = 16
    cols = 24
    lines = data_text.rsplit('\n')
    
    for i in range(len(lines)):
        if lines[i] == "start printing":
            i_start = i + 1
        if lines[i] == "end printing":
            i_end = i
    res = [0 for i in range((rows-2)*(cols-2))]
    for i in range(i_start, i_end):
        if lines[i][:10] == 'printing: ':
            res_i = [int(x) for x in lines[i][10:].rsplit(',')]
            res[(res_i[1]-1)*(cols-2) + res_i[2] - 1] = res_i[0]
    return res

# can be used for PLAID layouts, if there is a need to regenerate them
def extract_info_plaid(data_text):
    for line in data_text.rsplit('\n'):
        if line[:6] == 'Plate:':
            res = line[6:]
    return res

def extract_info_dose_response(
    output_text,
    rows=16,
    columns=24,
    expected_compound_replicates=1,
):
    """Parse COMPD dose-response output and restore canonical dose IDs.

    Requires two MiniZinc output blocks:

        printing: <randomized-slot-id>,<inner-row>,<inner-column>
        mapping:  <compound>,<slot>,<canonical-dose-index>,<dose-label>

    The returned layout uses canonical compound-major IDs, so concentration
    randomization in COMPD does not change the stored dose identity.
    """
    lines = [line.strip() for line in output_text.splitlines()]

    def block_bounds(start_marker, end_marker):
        start_positions = [
            index
            for index, line in enumerate(lines)
            if line == start_marker
        ]

        if not start_positions:
            raise ValueError(
                f"Missing MiniZinc output marker {start_marker!r}."
            )

        start = start_positions[-1] + 1

        end = next(
            (
                index
                for index in range(start, len(lines))
                if lines[index] == end_marker
            ),
            None,
        )

        if end is None:
            raise ValueError(
                f"Missing {end_marker!r} after the final "
                f"{start_marker!r} marker."
            )

        return start, end

    mapping_start, mapping_end = block_bounds(
        "start concentration mapping",
        "end concentration mapping",
    )

    mapping_records = []

    for line in lines[mapping_start:mapping_end]:
        if not line.startswith("mapping: "):
            continue

        fields = line[len("mapping: "):].split(",", maxsplit=3)

        if len(fields) != 4:
            raise ValueError(
                f"Malformed concentration-mapping record: {line!r}"
            )

        compound, slot, canonical_dose, dose_label = fields

        try:
            mapping_records.append(
                (
                    int(compound),
                    int(slot),
                    int(canonical_dose),
                    dose_label,
                )
            )
        except ValueError as exc:
            raise ValueError(
                f"Non-integer compound, slot, or dose index in: {line!r}"
            ) from exc

    if not mapping_records:
        raise ValueError(
            "No concentration-mapping records were found. Ensure that "
            "plate-optimizer-output-dose-response.mzn prints the "
            "'start concentration mapping' block."
        )

    mapping_records.sort(key=lambda record: (record[0], record[1]))

    compound_counts = {}
    seen_compound_slot = set()
    seen_compound_dose = set()

    for compound, slot, canonical_dose, _ in mapping_records:
        if compound < 1 or slot < 1 or canonical_dose < 1:
            raise ValueError(
                "Compound, randomized slot, and canonical dose indices "
                f"must all be positive: {(compound, slot, canonical_dose)}"
            )

        compound_slot_key = (compound, slot)
        compound_dose_key = (compound, canonical_dose)

        if compound_slot_key in seen_compound_slot:
            raise ValueError(
                f"Duplicate compound/slot mapping: {compound_slot_key}"
            )

        if compound_dose_key in seen_compound_dose:
            raise ValueError(
                "The randomization mapping is not a permutation: "
                f"canonical dose {canonical_dose} occurs more than once "
                f"for compound {compound}."
            )

        seen_compound_slot.add(compound_slot_key)
        seen_compound_dose.add(compound_dose_key)

        compound_counts[compound] = max(
            compound_counts.get(compound, 0),
            slot,
            canonical_dose,
        )

    compounds = sorted(compound_counts)

    if compounds != list(range(1, len(compounds) + 1)):
        raise ValueError(
            "Compound numbers in the mapping must be consecutive, starting "
            f"at 1; found {compounds}."
        )

    for compound in compounds:
        concentration_count = compound_counts[compound]

        expected_slots = set(range(1, concentration_count + 1))
        actual_slots = {
            slot
            for mapped_compound, slot, _, _ in mapping_records
            if mapped_compound == compound
        }

        actual_doses = {
            canonical_dose
            for mapped_compound, _, canonical_dose, _ in mapping_records
            if mapped_compound == compound
        }

        if actual_slots != expected_slots:
            raise ValueError(
                f"Compound {compound} does not have contiguous randomized "
                f"slots 1..{concentration_count}: {sorted(actual_slots)}"
            )

        if actual_doses != expected_slots:
            raise ValueError(
                f"Compound {compound} does not map onto canonical dose "
                f"indices 1..{concentration_count}: {sorted(actual_doses)}"
            )

    compound_offset = {}
    running_total = 0

    for compound in compounds:
        compound_offset[compound] = running_total
        running_total += compound_counts[compound]

    randomized_id_to_canonical_id = {}

    for compound, slot, canonical_dose, _ in mapping_records:
        randomized_id = compound_offset[compound] + slot
        canonical_id = compound_offset[compound] + canonical_dose

        randomized_id_to_canonical_id[randomized_id] = canonical_id

    total_compound_concentrations = running_total
    control_id = total_compound_concentrations + 1

    print_start, print_end = block_bounds(
        "start printing",
        "end printing",
    )

    layout = [0] * ((rows - 2) * (columns - 2))
    canonical_id_counts = Counter()

    for line in lines[print_start:print_end]:
        if not line.startswith("printing: "):
            continue

        try:
            printed_id, row, column = map(
                int,
                line[len("printing: "):].split(","),
            )
        except ValueError as exc:
            raise ValueError(
                f"Malformed layout record: {line!r}"
            ) from exc

        if not (1 <= row <= rows - 2):
            raise ValueError(
                f"Invalid inner row {row}; expected 1..{rows - 2}."
            )

        if not (1 <= column <= columns - 2):
            raise ValueError(
                f"Invalid inner column {column}; expected 1..{columns - 2}."
            )

        if printed_id in randomized_id_to_canonical_id:
            canonical_id = randomized_id_to_canonical_id[printed_id]

        elif printed_id == control_id:
            canonical_id = control_id

        else:
            raise ValueError(
                f"Unexpected printed material ID {printed_id}; expected a "
                f"compound slot in 1..{total_compound_concentrations} or "
                f"control ID {control_id}."
            )

        well_index = (row - 1) * (columns - 2) + (column - 1)

        if layout[well_index] != 0:
            raise ValueError(
                f"Two materials were assigned to inner well ({row}, {column})."
            )

        if canonical_id <= total_compound_concentrations:
            canonical_id_counts[canonical_id] += 1

        layout[well_index] = canonical_id

    expected_compound_ids = set(
        range(1, total_compound_concentrations + 1)
    )

    observed_compound_ids = set(canonical_id_counts)

    missing_ids = sorted(
        expected_compound_ids.difference(observed_compound_ids)
    )

    unexpected_ids = sorted(
        observed_compound_ids.difference(expected_compound_ids)
    )

    incorrect_counts = {
        compound_dose_id: canonical_id_counts[compound_dose_id]
        for compound_dose_id in sorted(expected_compound_ids)
        if canonical_id_counts[compound_dose_id]
        != expected_compound_replicates
    }

    if missing_ids or unexpected_ids or incorrect_counts:
        raise ValueError(
            "Canonical compound-dose replication validation failed. "
            f"Expected {expected_compound_replicates} occurrence(s) of every "
            f"compound-dose ID. Missing IDs: {missing_ids}; "
            f"unexpected IDs: {unexpected_ids}; "
            f"incorrect counts: {incorrect_counts}."
        )

    return layout


def save_plaid_layout(plate_id, layout_array, num_rows=16, num_columns=24, compounds=36, concentrations=4, replicates=2, size_empty_edge=1, neg_controls=20,directory="layouts/compounds_PLAID_layouts"):

    assert size_empty_edge >= 0
    assert num_rows >= 0
    assert num_columns >= 0
    
    layout = np.reshape(layout_array, (-1, num_columns-2*size_empty_edge))
    
    if size_empty_edge > 0:
        vertical_edge = np.reshape(np.full(size_empty_edge*(num_rows-2*size_empty_edge),0), (-1,size_empty_edge))
                         
        layout = np.hstack((vertical_edge,layout))
    
        layout = np.hstack((layout,vertical_edge))
    
        horizontal_edge = np.reshape(np.full(size_empty_edge*num_columns,0), (-1,num_columns))
    
        layout = np.vstack((horizontal_edge,layout))
    
        layout = np.vstack((layout,horizontal_edge))
    
    print(layout)
    np.save(directory+'/plate_layout_'+str(neg_controls)+"-"+str(compounds)+"-"+str(concentrations)+"-"+str(replicates)+"_"+plate_id+'.npy',layout)

    
def _shape_layout(layout, num_rows, num_columns, size_empty_edge):
    layout = np.reshape(layout,(-1, num_columns-2*size_empty_edge))
    
    if size_empty_edge > 0:
        vertical_edge = np.reshape(np.full(size_empty_edge*(num_rows-2*size_empty_edge),0), (-1,size_empty_edge))
                         
        layout = np.hstack((vertical_edge,layout))
    
        layout = np.hstack((layout,vertical_edge))
    
        horizontal_edge = np.reshape(np.full(size_empty_edge*num_columns,0), (-1,num_columns))
    
        layout = np.vstack((horizontal_edge,layout))
    
        layout = np.vstack((layout,horizontal_edge))
    
    return layout


def save_plaid_controls_layout(plate_id, layout_array, num_rows=16, num_columns=24, size_empty_edge=1, directory="layouts/controls_PLAID_layouts"):
    layout = __shape_layout(layout_array, num_rows, num_columns, size_empty_edge)
    
    layout = get_controls_layout(layout)
    
    print(layout)
    np.save(directory+'/plate_layout_'+plate_id+'.npy',layout)
    
    
def get_controls_layout(layout, neg_control = None):
    num_rows, num_columns = layout.shape
    
    if neg_control is None:
        control = np.max(layout)
    else:
        control = neg_control

    control_layout = np.full((num_rows, num_columns), 0)

    for row_i in range(num_rows):
        for col_i in range(num_columns):
            if layout[row_i][col_i] == control:
                control_layout[row_i][col_i] = 1

    return(control_layout)



def save_plaid_screening_layout(plate_id, layout_array, num_rows=16, num_columns=24, size_empty_edge=1, directory="layouts/screening_PLAID_layouts"):
    neg_id = np.max(layout_array)
    pos_id = neg_id - 1
    
    neg_controls = layout_array.count(neg_id)
    pos_controls = layout_array.count(pos_id)
    
    layout = __shape_layout(layout_array, num_rows, num_columns, size_empty_edge)
    
    print(layout)
    np.save(directory+'/plate_layout_'+str(neg_controls)+"-"+str(pos_controls)+"_"+plate_id+'.npy',layout)
    
    
def create_random_layout_screening(plate_id, neg_controls=10, pos_controls = 10, num_rows=16, num_columns=24, directory="layouts/screening_manual_layouts", size_empty_edge=1):
    '''Create a random layout for a screening experiment'''
    
    total_compounds = (num_rows-2*size_empty_edge)*(num_columns-2*size_empty_edge)-neg_controls-pos_controls
    
    layout = [(total_compounds+1) for i in range(pos_controls)]+[(total_compounds+2) for i in range(neg_controls)]+[(i+1) for i in range(total_compounds)]
    random.shuffle(layout)
    
    layout = __shape_layout(layout, num_rows, num_columns, size_empty_edge)
    
    print(layout)
    np.save(directory+'/plate_layout_rand_'+str(neg_controls)+"-"+str(pos_controls)+"_"+plate_id+'.npy',layout)

def paths():
    # list relevant paths:
    minizinc_path = '/Applications/MiniZincIDE.app/Contents/Resources/minizinc'
    project_path = 'compd-files/'
    return minizinc_path, project_path

def run_config(config, model_files_list,
               data_directory = 'dzn-files/screening/',
               npy_directory = 'layouts/screening_COMPD_layouts',
               num_max = 40):
    (minizinc_path, project_path) = paths()

    os.makedirs(os.path.dirname(npy_directory + '/'), exist_ok = True)

    data_file_list = [each for each in os.listdir(data_directory) if each.endswith('.dzn')]

    print('data_file_list = ', data_file_list)
    
    print(config + ':')

    times = [[0 for i in range(num_max)] for j in range(len(data_file_list))]
    r = -1

    for data_file in data_file_list:
        r += 1
        for k in range(num_max):
            print(data_file, k)
            t_start = time.perf_counter()
            cmd_to_str = run_cmd(minizinc_path, project_path,
                                 config, model_files_list, data_directory, data_file)
            #array_string = extract_info_plaid(cmd_to_str)
            array_nums = extract_info(cmd_to_str)
            t_end = time.perf_counter()
            #print(data_file, t_end - t_start, array_string[:10])
            times[r][k] = t_end - t_start
            save_plaid_screening_layout(str(k+1).zfill(2),
                                        array_nums,
                                        16, 24, 1,
                                        npy_directory)
            print(times[r][k])
        
    print('finished')
    for t in times:
        print(t)


def run_config_d_r(config, model_files_list,
                   data_directory = 'dzn-files/compounds/',
                   npy_directory = 'layouts/compounds_COMPD_layouts',
                   num_max = 20):
    (minizinc_path, project_path) = paths()

    os.makedirs(os.path.dirname(npy_directory + '/'), exist_ok = True)

    #data_file_list = [each for each in os.listdir(data_directory) if each.endswith('.dzn')]

    #print('data_file_list = ', data_file_list)
    
    print(config + ':')

    concentrations_list = [6, 8, 12]
    replicates_list = [1, 2, 3]
    

    times = [[0 for i in range(num_max)] for j in range(len(concentrations_list) * len(replicates_list))]
    r = -1

    for concentrations in concentrations_list:
        for replicates in replicates_list:
            r += 1
            compounds = (14*22-20)//(concentrations*replicates)
            
            data_file = 'compounds-validation-' + str(compounds)+'-'+str(concentrations)+'-'+str(replicates) + '.dzn'
            print(data_file,':')
                        
            for k in range(num_max):
                print(concentrations, replicates, k)
                
#                if not (compounds,concentrations,replicates, k) in [(8,12,3,0),
#                                                                    (24,12,1,8),
#                                                                    (48,6,1,0),
#                                                                    (24,6,2,0),
#                                                                    (36,8,1,1),
#                                                                    (18,8,2,1),
#                                                                    (12,8,3,0)]:
#                    continue
                
                t_start = time.perf_counter()
                cmd_to_str = run_cmd(minizinc_path, project_path,
                                     config, model_files_list, data_directory, data_file)
                array_nums = extract_info_dose_response(
                    cmd_to_str,
                    expected_compound_replicates=replicates,
                )
                t_end = time.perf_counter()
                times[r][k] = t_end - t_start
#def save_plaid_layout(plate_id, layout_array, num_rows=16, num_columns=24, compounds=36, concentrations=4, replicates=2, size_empty_edge=1, neg_controls=20,directory="layouts/compounds_PLAID_layouts"):                
                save_plaid_layout(str(k+1).zfill(2),
                                  array_nums,
                                  16, 24, compounds, concentrations, replicates, 1, 20,
                                  npy_directory)
                print(times[r][k])
        
    print('finished')
    for t in times:
        print(t)
